# PIGT-DT Hybrid Underwater Acoustic–Optical Communication

Research implementation scaffold for a **Physics-Informed, Uncertainty-Aware Graph-Temporal Digital Twin** for adaptive underwater acoustic (AC), optical (OP), and hybrid (HYB) communication.

## What was added
- Executable prediction baseline suite: Persistence, AR, SVR, Random Forest, Extra Trees, Gradient Boosting, LSTM, GRU, TCN, Transformer, GNN-Transformer, PIGT-DT.
- Executable controller comparison suite: fixed power, AC-only, OP-only, threshold/SNR/energy-aware hybrid, PC-MAC, PC-MAC-DT, MADDPG/MAPPO comparison-policy proxies, PIGT-DT.
- Executable ablation experiments and CSV outputs.
- Publication-style plot generator producing model, controller, trade-off, seed, ablation, prediction-trace and switching figures.
- Real-data adapter remains available: place prepared CSV in `data/processed/unified.csv` and run `python scripts/run_all.py --real`.
- Literature/data comparison matrix in `docs/BASELINES_AND_COMPARISON_WORKS.md`.

## Important scientific rule
The bundled synthetic benchmark is **not a scientific result**. It exists to verify the code and generate example figures. Final paper numbers must be generated from independent real/high-fidelity test data and documented training configurations.

## Main workflow
```bash
pip install -r requirements.txt
python scripts/run_all.py
```
For a prepared real dataset:
```bash
python scripts/prepare_real_data.py --input data/raw --output data/processed/unified.csv
python scripts/run_all.py --real
```

## Outputs
- `results/prediction_comparison.csv`
- `results/prediction_traces.csv`
- `results/controller_comparison.csv`
- `results/ablation_results.csv`
- `results/benchmark_metadata.json`
- `results/figures/*.png`

## Publication figures
The plot generator creates:
- prediction MAE/RMSE/bias comparisons
- prediction family comparison
- controller PDR/throughput/BER/energy/switching comparisons
- reliability-energy and throughput-energy trade-offs
- seed variability
- controller metric heatmap
- prediction error landscape
- actual-vs-predicted traces
- residual histogram and error quantiles
- adaptive mode switching
- ablation plots

## Real-data strategy
Recommended hierarchy:
1. ALOMEX 2015 for simultaneous acoustic/optical measurements.
2. Underwater Acoustic Channel Repository/KAM11 for external acoustic validation.
3. Independent UWOC measurements for optical validation.
4. BELLHOP/AquaSim and optical physics simulation only for augmentation and model-mismatch/OOD testing.

Never mix samples from the same physical environment across train and test. Prefer environment/station-level splits.
