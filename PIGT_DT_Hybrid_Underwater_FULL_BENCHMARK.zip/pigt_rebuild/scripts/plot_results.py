import json
from pathlib import Path
import matplotlib.pyplot as plt
Path('results/figures').mkdir(parents=True,exist_ok=True)
for fn,title,ylabel in [('predictor_metrics.json','Predictor metrics','value'),('controller_metrics.json','Controller metrics','value')]:
 p=Path('results')/fn
 if not p.exists(): continue
 d=json.loads(p.read_text()); vals={}
 def walk(x,k=''):
  if isinstance(x,dict):
   for a,b in x.items(): walk(b,k+'/'+a)
  elif isinstance(x,(int,float)): vals[k]=x
 walk(d)
 plt.figure(figsize=(9,5)); plt.bar(range(len(vals)),list(vals.values())); plt.xticks(range(len(vals)),list(vals.keys()),rotation=60,ha='right'); plt.title(title); plt.ylabel(ylabel); plt.tight_layout(); plt.savefig(Path('results/figures')/(fn.replace('.json','.png')),dpi=180); plt.close()
print('Figures written to results/figures')
