import subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def run(x): subprocess.run([sys.executable,str(R/x)],cwd=R,check=True)
# Synthetic fallback is intentional for CI/software verification; pass --real to benchmark user data.
import argparse
ap=argparse.ArgumentParser(); ap.add_argument('--real',action='store_true'); a=ap.parse_args()
cmd=R/'scripts/run_full_benchmark.py'; args=[] if a.real else ['--synthetic']; subprocess.run([sys.executable,str(cmd),*args],cwd=R,check=True)
run(Path('scripts/run_ablation.py')); run(Path('scripts/generate_all_plots.py'))
print('Complete benchmark + ablation + plotting pipeline finished. Inspect results/benchmark_metadata.json before treating outputs as scientific results.')
