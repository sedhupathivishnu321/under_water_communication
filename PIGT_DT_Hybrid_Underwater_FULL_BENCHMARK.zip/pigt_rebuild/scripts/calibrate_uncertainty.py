import json,sys
from pathlib import Path
p=Path('results/predictor_metrics.json')
if p.exists(): print(p.read_text())
else: print('Run evaluate_predictor.py first.')
