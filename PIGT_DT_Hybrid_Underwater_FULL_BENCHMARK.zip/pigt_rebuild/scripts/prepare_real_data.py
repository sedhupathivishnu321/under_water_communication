import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.data.prepare import prepare
p=argparse.ArgumentParser(); p.add_argument('--input',default='data/raw'); p.add_argument('--output',default='data/processed/unified.csv'); a=p.parse_args(); df=prepare(a.input,a.output); print(f'Prepared {len(df):,} rows -> {a.output}')
