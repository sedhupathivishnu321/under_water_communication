"""Run reproducible benchmark suite. If real prepared data are present, use them; otherwise generate a clearly labelled synthetic stress-test dataset."""
import argparse, json, sys, time
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.multioutput import MultiOutputRegressor
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.benchmarks.predictors import build_sequences, persistence_predict, ar_predict, fit_sklearn_baseline
from pigt_dt.benchmarks.controllers import evaluate_controller_suite
from pigt_dt.data.synthetic import make_benchmark_dataframe

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)


def metrics(y,p):
    e=y-p
    return {'MAE':float(np.mean(np.abs(e))), 'RMSE':float(np.sqrt(np.mean(e**2))), 'Bias':float(np.mean(e))}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data',default='data/processed/unified.csv'); ap.add_argument('--synthetic',action='store_true'); ap.add_argument('--seeds',default='0,1,2'); args=ap.parse_args()
    data=Path(args.data)
    if data.exists() and not args.synthetic:
        df=pd.read_csv(data); source='real_prepared_or_user_data'
    else:
        df=make_benchmark_dataframe(seed=2026, environments=8, steps=50); source='synthetic_benchmark_not_scientific_result'
        df.to_csv(OUT/'synthetic_benchmark.csv',index=False)
    Xtr,ytr,Xte,yte,meta=build_sequences(df, train_frac=.7, test_frac=.2)
    results=[]; traces=[]
    # Persistence
    p=persistence_predict(Xte); traces.append(pd.DataFrame({'model':'Persistence','sample':np.arange(len(p)),'actual_ac_snr':yte[:,0],'pred_ac_snr':p[:,0],'actual_op_snr':yte[:,1],'pred_op_snr':p[:,1]})); results.append({'model':'Persistence','family':'Classical','split':source,**metrics(yte,p)})
    # AR
    p=ar_predict(Xte, order=3); traces.append(pd.DataFrame({'model':'AR(3)','sample':np.arange(len(p)),'actual_ac_snr':yte[:,0],'pred_ac_snr':p[:,0],'actual_op_snr':yte[:,1],'pred_op_snr':p[:,1]})); results.append({'model':'AR(3)','family':'Classical','split':source,**metrics(yte,p)})
    # Strong sklearn baselines
    flat_tr=Xtr.reshape(len(Xtr),-1); flat_te=Xte.reshape(len(Xte),-1)
    for name,est in [
        ('SVR',MultiOutputRegressor(SVR(C=10,gamma='scale'))),
        ('Random Forest',RandomForestRegressor(n_estimators=120,max_depth=12,random_state=0,n_jobs=-1)),
        ('Extra Trees',ExtraTreesRegressor(n_estimators=120,max_depth=14,random_state=0,n_jobs=-1)),
        ('Gradient Boosting',MultiOutputRegressor(GradientBoostingRegressor(random_state=0,n_estimators=100,max_depth=3)) )]:
        p=fit_sklearn_baseline(est,flat_tr,ytr,flat_te); traces.append(pd.DataFrame({'model':name,'sample':np.arange(len(p)),'actual_ac_snr':yte[:,0],'pred_ac_snr':p[:,0],'actual_op_snr':yte[:,1],'pred_op_snr':p[:,1]})); results.append({'model':name,'family':'ML','split':source,**metrics(yte,p)})
    # Compact neural baselines are handled in benchmark model module.
    from pigt_dt.benchmarks.torch_predictors import train_torch_baselines, train_pigt_dt
    neural=train_torch_baselines(Xtr,ytr,Xte,yte,seeds=[int(s) for s in args.seeds.split(',')])
    results.extend(neural)
    pigt=train_pigt_dt(Xtr,ytr,Xte,yte,seeds=[int(s) for s in args.seeds.split(',')])
    results.extend(pigt)
    # Refit one PIGT instance to expose trace data for figures.
    from pigt_dt.benchmarks.torch_predictors import PhysicsPIGT, train_one
    # The trace is optional; benchmark comparison metrics remain the primary output.
    pp=train_one(PhysicsPIGT(Xtr.shape[-1],16,4),Xtr,ytr,Xte,yte,0)
    traces.append(pd.DataFrame({'model':'PIGT-DT','sample':np.arange(len(pp)),'actual_ac_snr':yte[:,0],'pred_ac_snr':pp[:,0],'actual_op_snr':yte[:,1],'pred_op_snr':pp[:,1]}))
    # Controller suite is independent from predictor benchmarking.
    ctrl=evaluate_controller_suite(seeds=[int(s) for s in args.seeds.split(',')], nodes=8, steps=80)
    pd.DataFrame(results).to_csv(OUT/'prediction_comparison.csv',index=False)
    pd.concat(traces,ignore_index=True).to_csv(OUT/'prediction_traces.csv',index=False)
    ctrl.to_csv(OUT/'controller_comparison.csv',index=False)
    meta_out={'data_source':source,'n_rows':len(df),'train_sequences':len(Xtr),'test_sequences':len(Xte),'note':'Synthetic fallback is for software/plot verification only.'}
    json.dump(meta_out,open(OUT/'benchmark_metadata.json','w'),indent=2)
    print(pd.DataFrame(results).to_string(index=False)); print('\nController suite:'); print(ctrl.groupby('model').mean(numeric_only=True).to_string())

if __name__=='__main__': main()
