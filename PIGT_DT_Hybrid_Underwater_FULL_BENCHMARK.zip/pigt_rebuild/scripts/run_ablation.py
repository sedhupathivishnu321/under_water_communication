"""Executable ablations. These are benchmark stress tests; real-data claims require real-data inputs."""
import argparse,sys
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
from pigt_dt.data.synthetic import make_benchmark_dataframe
from pigt_dt.benchmarks.predictors import build_sequences,persistence_predict
from pigt_dt.benchmarks.torch_predictors import train_one,RNN,TCN,Transformer,GNNTransformer

def err(y,p): return float(np.sqrt(np.mean((y-p)**2)))
def main():
    df=make_benchmark_dataframe(2026,12,80); X,y,Xt,yt,_=build_sequences(df)
    rows=[]
    # physics/data architecture proxies: progressively remove components from predictor inputs
    configs=[('A0_physics_only','persistence'),('A1_data_only','gru'),('A2_physics_residual','lstm'),('A3_tcn','tcn'),('A4_transformer','transformer'),('A5_gnn_transformer','gnn_transformer')]
    for name,kind in configs:
        for seed in [0,1]:
            if kind=='persistence': pr=persistence_predict(Xt)
            else:
                cls={'gru':lambda:RNN(6,48,4,'gru'),'lstm':lambda:RNN(6,48,4,'lstm'),'tcn':lambda:TCN(6,48,4),'transformer':lambda:Transformer(6,48,4),'gnn_transformer':lambda:GNNTransformer(6,48,4)}[kind]; pr=train_one(cls(),X,y,Xt,yt,seed)
            rows.append({'experiment':name,'seed':seed,'RMSE':err(yt,pr),'MAE':float(np.mean(np.abs(yt-pr)))})
    # uncertainty ensemble-size proxy using seed dispersion
    for m in [1,3]:
        preds=[]
        for s in range(m): preds.append(train_one(RNN(6,48,4,'gru'),X,y,Xt,yt,s))
        p=np.mean(preds,axis=0); rows.append({'experiment':f'A6_ensemble_M{m}','seed':0,'RMSE':err(yt,p),'MAE':float(np.mean(np.abs(yt-p)))})
    out=pd.DataFrame(rows); ROOT.joinpath('results').mkdir(exist_ok=True); out.to_csv(ROOT/'results/ablation_results.csv',index=False); print(out.groupby('experiment').mean(numeric_only=True).to_string())
if __name__=='__main__': main()
