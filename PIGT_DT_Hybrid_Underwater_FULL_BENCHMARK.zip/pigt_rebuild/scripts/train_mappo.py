import argparse,sys
from pathlib import Path
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.marl.mappo import MAPPO
p=argparse.ArgumentParser(); p.add_argument('--agents',type=int,default=4); a=p.parse_args(); m=MAPPO(obs_dim=6,state_dim=6*a.agents,agents=a.agents); obs=torch.randn(2,a.agents,6); state=obs.flatten(1); acts,logp=m.act(obs); print('MAPPO smoke:',acts.shape,logp.shape,m.value(state).shape)
