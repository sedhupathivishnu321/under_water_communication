import sys,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
cmds=[['python',str(root/'scripts/prepare_real_data.py')],['python',str(root/'scripts/run_controller.py')],['python',str(root/'scripts/run_ablation.py')]]
for c in cmds: subprocess.run(c,cwd=root,check=True)
print('Smoke pipeline completed. These outputs are software checks, not scientific results.')
