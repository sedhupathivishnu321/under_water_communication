import argparse,sys,numpy as np,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.simulation.hybrid_env import HybridEnv
from pigt_dt.control.risk_controller import RiskController
from pigt_dt.utils.io import load_yaml
p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/default.yaml'); a=p.parse_args(); cfg=load_yaml(a.config); env=HybridEnv(cfg['simulation']['nodes'],cfg['simulation']['steps'],cfg['simulation']['seed']); ctrl=RiskController(cfg); obs=env.reset(); logs=[]
for _ in range(cfg['simulation']['steps']):
    actions=[]
    for row in obs:
        # surrogate DT estimate from current state
        ac=float(row[3]); op=float(row[4]); pred=np.array([ac,1e-3,.95,max(1,10**(ac/12)*10),op,1e-3,.95,max(1,10**(op/10)*5)]); sig=np.ones(8)*.5; r=ctrl.choose(pred,sig); mode={'AC':0,'OP':1,'HYB':2}[r[1]]; actions.append([mode,10.0])
    obs,reward,done,info=env.step(actions); logs.append({'reward':reward,**info})
Path('results').mkdir(exist_ok=True); json.dump({'mean_reward':float(np.mean([x['reward'] for x in logs])),'mean_pdr':float(np.mean([x['pdr'] for x in logs])),'mean_rate_kbps':float(np.mean([x['rate_kbps'] for x in logs])),'mean_ber':float(np.mean([x['ber'] for x in logs])),'mean_energy':float(np.mean([x['energy'] for x in logs]))},open('results/controller_metrics.json','w'),indent=2); print(json.dumps(json.load(open('results/controller_metrics.json')),indent=2))
