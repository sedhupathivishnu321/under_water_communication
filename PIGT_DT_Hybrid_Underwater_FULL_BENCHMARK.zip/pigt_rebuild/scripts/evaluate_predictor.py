import argparse,sys,json
from pathlib import Path
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.models.train import Predictor
from pigt_dt.utils.io import load_yaml
from pigt_dt.data.prepare import prepare
from pigt_dt.uncertainty.calibration import calibration_metrics
from pigt_dt.evaluation.metrics import regression
# Evaluates a held-out environment split using the saved predictor checkpoint.
p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/default.yaml'); p.add_argument('--data',default='data/processed/unified.csv'); a=p.parse_args(); cfg=load_yaml(a.config); df=pd.read_csv(a.data); env=sorted(df.environment_id.unique()); n=len(env); tr=df[df.environment_id.isin(env[:max(1,int(.7*n))])]; va=df[df.environment_id.isin(env[max(1,int(.7*n)):max(2,int(.85*n))])]; te=df[df.environment_id.isin(env[max(2,int(.85*n)):])]; m=Predictor(cfg).load('models/pigt_dt_predictor.pt'); X,y,_=m.sequences(te); mu,sig=m.predict(X); out={'overall':regression(y,mu),'uncertainty':calibration_metrics(y,mu,sig)}; Path('results').mkdir(exist_ok=True); json.dump(out,open('results/predictor_metrics.json','w'),indent=2); print(json.dumps(out,indent=2))
