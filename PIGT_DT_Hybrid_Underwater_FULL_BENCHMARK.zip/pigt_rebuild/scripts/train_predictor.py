import argparse,sys,yaml
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.models.train import Predictor
from pigt_dt.utils.io import load_yaml,seed_everything
p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/default.yaml'); p.add_argument('--data',default='data/processed/unified.csv'); a=p.parse_args(); cfg=load_yaml(a.config); seed_everything(cfg['seed']); df=pd.read_csv(a.data); env=sorted(df.environment_id.unique()); n=len(env); train=set(env[:max(1,int(.7*n))]); val=set(env[max(1,int(.7*n)):max(2,int(.85*n))]); tr=df[df.environment_id.isin(train)]; va=df[df.environment_id.isin(val)]; model=Predictor(cfg).fit(tr,va); model.save('models/pigt_dt_predictor.pt'); print('saved models/pigt_dt_predictor.pt')
