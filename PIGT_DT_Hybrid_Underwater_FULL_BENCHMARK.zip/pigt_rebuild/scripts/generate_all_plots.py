"""Generate publication-style figures from benchmark CSVs and optional ablation outputs."""
import argparse
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'results'/'figures'; OUT.mkdir(parents=True,exist_ok=True)

def save(name): plt.tight_layout(); plt.savefig(OUT/name,dpi=240,bbox_inches='tight'); plt.close()

def bar(df,x,y,title,ylabel,sort=False):
    g=df.groupby(x)[y].mean().sort_values() if sort else df.groupby(x)[y].mean()
    plt.figure(figsize=(10,5)); plt.bar(g.index.astype(str),g.values); plt.xticks(rotation=45,ha='right'); plt.title(title); plt.ylabel(ylabel); save(name_slug(title)+'.png')
def name_slug(s): return ''.join(c.lower() if c.isalnum() else '_' for c in s).strip('_')

def main():
    pred=pd.read_csv(ROOT/'results/prediction_comparison.csv')
    ctrl=pd.read_csv(ROOT/'results/controller_comparison.csv')
    # 1-4 predictor comparisons
    for metric in ['MAE','RMSE','Bias']:
        g=pred.groupby('model')[metric].mean().sort_values(); plt.figure(figsize=(11,5)); plt.bar(g.index,g.values); plt.xticks(rotation=55,ha='right'); plt.ylabel(metric); plt.title(f'Prediction comparison — {metric}'); save(f'01_prediction_{metric.lower()}.png')
    # family comparison
    g=pred.groupby('family')['RMSE'].mean(); plt.figure(figsize=(8,4)); plt.bar(g.index,g.values); plt.ylabel('RMSE'); plt.title('Prediction error by model family'); save('02_prediction_family_rmse.png')
    # 5-7 controller
    for metric in ['PDR','Throughput_kbps','BER','Energy_used','Switch_rate']:
        g=ctrl.groupby('model')[metric].mean(); plt.figure(figsize=(11,5)); plt.bar(g.index,g.values); plt.xticks(rotation=55,ha='right'); plt.ylabel(metric); plt.title(f'Controller comparison — {metric}'); save(f'03_controller_{metric.lower()}.png')
    # 8 reliability-energy scatter
    g=ctrl.groupby('model')[['PDR','Energy_used','Throughput_kbps','BER']].mean().reset_index(); plt.figure(figsize=(8,6)); plt.scatter(g.Energy_used,g.PDR,s=60); 
    for _,r in g.iterrows(): plt.annotate(r.model,(r.Energy_used,r.PDR),fontsize=8,xytext=(4,4),textcoords='offset points')
    plt.xlabel('Energy used'); plt.ylabel('PDR'); plt.title('Reliability–energy trade-off'); save('04_reliability_energy_tradeoff.png')
    # 9 throughput-energy
    plt.figure(figsize=(8,6)); plt.scatter(g.Energy_used,g.Throughput_kbps,s=60); 
    for _,r in g.iterrows(): plt.annotate(r.model,(r.Energy_used,r.Throughput_kbps),fontsize=8,xytext=(4,4),textcoords='offset points')
    plt.xlabel('Energy used'); plt.ylabel('Throughput (kbps)'); plt.title('Throughput–energy trade-off'); save('05_throughput_energy_tradeoff.png')
    # 10-12 seed variability
    for metric in ['PDR','Throughput_kbps','BER']:
        plt.figure(figsize=(11,5)); ctrl.boxplot(column=metric,by='model',rot=55); plt.suptitle(''); plt.title(f'Seed variability — {metric}'); plt.xlabel(''); plt.ylabel(metric); save(f'06_seed_box_{metric.lower()}.png')
    # 13 model ranking table-like heatmap
    metrics=['PDR','Throughput_kbps','BER','Energy_used']; h=ctrl.groupby('model')[metrics].mean(); z=(h-h.mean())/(h.std()+1e-9)
    plt.figure(figsize=(9,7)); plt.imshow(z.values,aspect='auto'); plt.colorbar(label='Standardized value'); plt.xticks(range(len(metrics)),metrics,rotation=35,ha='right'); plt.yticks(range(len(h)),h.index); plt.title('Controller metric profile'); save('07_controller_metric_heatmap.png')
    # 14 baseline family scatter
    p=pred.groupby('model').mean(numeric_only=True).reset_index(); plt.figure(figsize=(8,6)); plt.scatter(p.MAE,p.RMSE,s=65); 
    for _,r in p.iterrows(): plt.annotate(r.model,(r.MAE,r.RMSE),fontsize=8,xytext=(4,4),textcoords='offset points')
    plt.xlabel('MAE'); plt.ylabel('RMSE'); plt.title('Prediction error landscape'); save('08_prediction_error_landscape.png')
    # 15 synthetic time-series demonstration, explicitly not measured
    if (ROOT/'results/synthetic_benchmark.csv').exists():
        d=pd.read_csv(ROOT/'results/synthetic_benchmark.csv'); e=d.environment_id.iloc[0]; q=d[d.environment_id==e].head(120); plt.figure(figsize=(11,4)); plt.plot(q.timestamp_s,q.ac_snr_db,label='Acoustic SNR'); plt.plot(q.timestamp_s,q.op_snr_db,label='Optical SNR'); plt.xlabel('Time (s)'); plt.ylabel('SNR (dB)'); plt.title('Synthetic benchmark channel trace (software verification only)'); plt.legend(); save('09_synthetic_channel_trace.png')
    # Prediction trace figures: actual vs predicted, residual distribution, and calibration-like coverage.
    tr=ROOT/'results/prediction_traces.csv'
    if tr.exists():
        td=pd.read_csv(tr)
        for model in td.model.unique():
            q=td[td.model==model].head(150)
            plt.figure(figsize=(10,4)); plt.plot(q['sample'], q.actual_ac_snr, label='Actual acoustic SNR'); plt.plot(q['sample'],q.pred_ac_snr,label='Predicted acoustic SNR'); plt.xlabel('Test sample'); plt.ylabel('SNR (dB)'); plt.title(f'Actual vs predicted acoustic SNR — {model}'); plt.legend(); save(f'11_trace_{name_slug(model)}.png')
        q=td.copy(); r=q.actual_ac_snr-q.pred_ac_snr; plt.figure(figsize=(9,5)); plt.hist(r,bins=30); plt.xlabel('Acoustic SNR residual (dB)'); plt.ylabel('Count'); plt.title('Prediction residual distribution'); save('12_prediction_residual_histogram.png')
        # calibration proxy: empirical absolute-error quantiles by model
        rows=[]
        for m,gp in q.groupby('model'):
            e=np.abs(gp.actual_ac_snr-gp.pred_ac_snr); rows.append((m,np.quantile(e,.5),np.quantile(e,.9),np.quantile(e,.95)))
        cal=pd.DataFrame(rows,columns=['model','q50','q90','q95']); plt.figure(figsize=(10,5)); x=np.arange(len(cal)); plt.plot(x,cal.q50,'o-',label='50th'); plt.plot(x,cal.q90,'o-',label='90th'); plt.plot(x,cal.q95,'o-',label='95th'); plt.xticks(x,cal.model,rotation=55,ha='right'); plt.ylabel('Absolute error (dB)'); plt.title('Prediction error quantiles'); plt.legend(); save('13_prediction_error_quantiles.png')
    # Mode switching profile
    counts=[]
    for m in ['AC-only','OP-only','Threshold hybrid','SNR hybrid','Energy-aware','PIGT-DT']:
        if m in ctrl.model.unique(): counts.append((m,ctrl[ctrl.model==m].Switch_rate.mean()))
    if counts:
        cd=pd.DataFrame(counts,columns=['model','switch']); plt.figure(figsize=(9,4)); plt.bar(cd.model,cd.switch); plt.xticks(rotation=45,ha='right'); plt.ylabel('Switch rate'); plt.title('Adaptive communication switching'); save('14_mode_switching.png')
    # 16 ablation plots if results exist
    ab=ROOT/'results/ablation_results.csv'
    if ab.exists():
        a=pd.read_csv(ab)
        for metric in [c for c in ['MAE','RMSE','PDR','Throughput_kbps','BER','Energy_used'] if c in a]:
            plt.figure(figsize=(11,5)); gg=a.groupby('experiment')[metric].mean().sort_values(); plt.bar(gg.index,gg.values); plt.xticks(rotation=55,ha='right'); plt.ylabel(metric); plt.title(f'Ablation — {metric}'); save(f'10_ablation_{metric.lower()}.png')
    print(f'Wrote {len(list(OUT.glob("*.png")))} figures to {OUT}')
if __name__=='__main__': main()
