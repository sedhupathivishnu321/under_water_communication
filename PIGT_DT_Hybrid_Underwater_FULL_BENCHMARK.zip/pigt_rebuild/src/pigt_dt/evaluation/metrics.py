import numpy as np

def regression(y,mu):
    e=y-mu; return {'mae':float(np.mean(np.abs(e))),'rmse':float(np.sqrt(np.mean(e**2))),'bias':float(np.mean(e))}

def summarize(rows):
    import pandas as pd
    return pd.DataFrame(rows).agg(['mean','std']).to_dict()
