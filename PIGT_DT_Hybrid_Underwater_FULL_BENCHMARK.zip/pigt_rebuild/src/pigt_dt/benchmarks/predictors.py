import numpy as np

def build_sequences(df, train_frac=.7, test_frac=.2, L=12, H=1):
    df=df.sort_values(['environment_id','timestamp_s']); env=sorted(df.environment_id.unique()); n=len(env)
    tr=set(env[:max(1,int(n*train_frac))]); te=set(env[max(1,int(n*(1-test_frac))):])
    def make(es):
        X=[];Y=[];M=[]
        for eid,g in df[df.environment_id.isin(es)].groupby('environment_id'):
            g=g.sort_values('timestamp_s'); x=g[['distance_m','depth_m','turbidity','ac_snr_db','op_snr_db','energy']].values; y=g[['ac_snr_db','op_snr_db','ac_ber','op_ber']].values
            for i in range(L,len(g)-H+1): X.append(x[i-L:i]); Y.append(y[i+H-1]); M.append(eid)
        return np.asarray(X,float),np.asarray(Y,float),M
    a,b,m1=make(tr); c,d,m2=make(te); return a,b,c,d,{'train_env':sorted(tr),'test_env':sorted(te),'train_ids':m1,'test_ids':m2}

def persistence_predict(X):
    last=X[:,-1]
    snra=last[:,3]; snro=last[:,4]
    return np.c_[snra,snro,np.clip(0.1*10**(-snra/10),1e-8,.5),np.clip(0.1*10**(-snro/10),1e-8,.5)]

def ar_predict(X,order=3):
    out=[]
    for seq in X:
        a=[]
        for j in [3,4]:
            z=seq[:,j]
            try:
                zz=z[-(order+20):]; Y=zz[order:]; A=np.column_stack([np.ones(len(Y)), zz[:-order]])
                for k in range(1,order): A=np.column_stack([A,zz[order-k:-k]])
                coef=np.linalg.lstsq(A,Y,rcond=None)[0]; hist=list(zz)
                row=[1.0]+[hist[-k] for k in range(1,order+1)]; a.append(float(np.dot(row,coef)))
            except Exception: a.append(float(z[-1]))
        out.append([a[0],a[1],max(1e-8,min(.5,.1*10**(-a[0]/10))),max(1e-8,min(.5,.1*10**(-a[1]/10)))])
    return np.asarray(out)

def fit_sklearn_baseline(est,Xtr,ytr,Xte):
    est.fit(Xtr,ytr); return est.predict(Xte)
