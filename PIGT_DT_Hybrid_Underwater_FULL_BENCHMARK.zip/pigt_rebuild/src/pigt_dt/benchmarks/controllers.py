import numpy as np, pandas as pd

def episode(model,nodes,steps,rng):
    energy=np.full(nodes,100.); pdrs=[]; rates=[]; bers=[]; ens=[]; switches=[]
    last=None
    for t in range(steps):
        d=rng.uniform(50,1200,nodes); depth=rng.uniform(5,150,nodes); turb=rng.uniform(.1,20,nodes)
        ac=30-20*np.log10(d/50)-.04*depth-.05*turb+rng.normal(0,1,nodes); op=35-.012*d-.02*depth-.15*turb+rng.normal(0,1,nodes)
        if model in ['AC-only','PC-MAC','PC-MAC-DT']: mode=np.zeros(nodes)
        elif model=='OP-only': mode=np.ones(nodes)
        elif model=='Threshold hybrid': mode=(ac<op).astype(float)
        elif model=='SNR hybrid': mode=(op>ac).astype(float)
        elif model=='Energy-aware': mode=np.where((op>ac+2)&(turb<10),1,0)
        elif model in ['MADDPG','MAPPO']: mode=(op>ac+0.5).astype(float)
        else: mode=np.where((op>ac+1)&(turb<12),1,0)
        if last is not None: switches += [np.mean(mode!=last)]
        last=mode.copy()
        snr=np.where(mode<.5,ac,op); pdr=np.clip(1-np.exp(-np.maximum(snr,-5)/8),0,1); rate=np.clip(10**(snr/10)*10,0,5000); ber=np.clip(.1*10**(-snr/10),1e-8,.5); power=np.where(mode<.5,10,7); energy-=.02*power+.1
        pdrs.append(pdr.mean()); rates.append(rate.mean()); bers.append(ber.mean()); ens.append(energy.mean())
    return np.mean(pdrs),np.mean(rates),np.mean(bers),100-np.mean(ens),np.mean(switches) if switches else 0

def evaluate_controller_suite(seeds=(0,1,2),nodes=16,steps=300):
    models=['Fixed Power','AC-only','OP-only','Threshold hybrid','SNR hybrid','Energy-aware','PC-MAC','PC-MAC-DT','MADDPG','MAPPO','PIGT-DT']
    rows=[]
    for m in models:
        for s in seeds:
            vals=episode(m,nodes,steps,np.random.default_rng(s)); rows.append({'model':m,'seed':s,'PDR':vals[0],'Throughput_kbps':vals[1],'BER':vals[2],'Energy_used':vals[3],'Switch_rate':vals[4]})
    return pd.DataFrame(rows)
