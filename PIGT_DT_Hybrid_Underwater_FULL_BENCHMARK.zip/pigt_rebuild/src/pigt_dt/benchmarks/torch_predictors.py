import numpy as np, torch
from torch import nn
from torch.utils.data import DataLoader,TensorDataset

class RNN(nn.Module):
    def __init__(self,d,hidden,out,kind='lstm'):
        super().__init__(); self.kind=kind
        if kind=='gru': self.r=nn.GRU(d,hidden,batch_first=True)
        else: self.r=nn.LSTM(d,hidden,batch_first=True)
        self.h=nn.Sequential(nn.LayerNorm(hidden),nn.Linear(hidden,out))
    def forward(self,x): return self.h(self.r(x)[0][:,-1])
class TCN(nn.Module):
    def __init__(self,d,h,out):
        super().__init__(); self.c=nn.Sequential(nn.Conv1d(d,h,3,padding=2,dilation=1),nn.GELU(),nn.Conv1d(h,h,3,padding=4,dilation=2),nn.GELU()); self.h=nn.Linear(h,out)
    def forward(self,x): return self.h(self.c(x.transpose(1,2))[:,:,-1])
class Transformer(nn.Module):
    def __init__(self,d,h,out):
        super().__init__(); self.p=nn.Linear(d,h); layer=nn.TransformerEncoderLayer(h,2,dropout=.1,batch_first=True,norm_first=True); self.t=nn.TransformerEncoder(layer,1); self.h=nn.Linear(h,out)
    def forward(self,x): return self.h(self.t(self.p(x))[:,-1])
class GNNTransformer(nn.Module):
    """Lightweight graph-temporal surrogate: node-wise attention plus temporal transformer."""
    def __init__(self,d,h,out):
        super().__init__(); self.g=nn.Linear(d,h); layer=nn.TransformerEncoderLayer(h,2,dropout=.1,batch_first=True,norm_first=True); self.t=nn.TransformerEncoder(layer,1); self.h=nn.Linear(h,out)
    def forward(self,x): return self.h(self.t(torch.tanh(self.g(x)))[:,-1])

def train_one(model,Xtr,ytr,Xte,yte,seed):
    torch.manual_seed(seed); np.random.seed(seed); dev='cuda' if torch.cuda.is_available() else 'cpu'; model.to(dev)
    xs=(Xtr-Xtr.mean((0,1)))/(Xtr.std((0,1))+1e-6); xt=(Xte-Xtr.mean((0,1)))/(Xtr.std((0,1))+1e-6); ys=(ytr-ytr.mean(0))/(ytr.std(0)+1e-6)
    dl=DataLoader(TensorDataset(torch.tensor(xs,dtype=torch.float32),torch.tensor(ys,dtype=torch.float32)),batch_size=128,shuffle=True)
    opt=torch.optim.AdamW(model.parameters(),lr=2e-3,weight_decay=1e-4); lossf=nn.SmoothL1Loss()
    model.train()
    for _ in range(1):
        for xb,yb in dl:
            pr=model(xb.to(dev)); loss=lossf(pr,yb.to(dev)); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),2); opt.step()
    model.eval();
    with torch.no_grad(): p=model(torch.tensor(xt,dtype=torch.float32).to(dev)).cpu().numpy()
    p=p*(ytr.std(0)+1e-6)+ytr.mean(0); return p

def train_torch_baselines(Xtr,ytr,Xte,yte,seeds):
    out=[]
    builders=[('LSTM','Deep Learning',lambda: RNN(Xtr.shape[-1],16,4,'lstm')),('GRU','Deep Learning',lambda: RNN(Xtr.shape[-1],16,4,'gru')),('TCN','Deep Learning',lambda: TCN(Xtr.shape[-1],16,4)),('Transformer','Attention',lambda: Transformer(Xtr.shape[-1],16,4)),('GNN-Transformer','Graph-Temporal',lambda: GNNTransformer(Xtr.shape[-1],16,4))]
    for name,fam,b in builders:
        vals=[]
        for s in seeds:
            p=train_one(b(),Xtr,ytr,Xte,yte,s); e=yte-p; vals.append((np.mean(np.abs(e)),np.sqrt(np.mean(e**2)),np.mean(e)))
        v=np.asarray(vals); out.append({'model':name,'family':fam,'split':'benchmark','MAE':float(v[:,0].mean()),'RMSE':float(v[:,1].mean()),'Bias':float(v[:,2].mean()),'MAE_std':float(v[:,0].std())})
    return out

class PhysicsPIGT(nn.Module):
    def __init__(self,d,h,out):
        super().__init__(); self.g=nn.Linear(d,h); layer=nn.TransformerEncoderLayer(h,2,dropout=.1,batch_first=True,norm_first=True); self.t=nn.TransformerEncoder(layer,1); self.h=nn.Linear(h,out)
    def forward(self,x): return self.h(self.t(torch.tanh(self.g(x)))[:,-1])

def train_pigt_dt(Xtr,ytr,Xte,yte,seeds):
    # Physics prior: deterministic acoustic/optical attenuation from measured geometry/turbidity; network learns residual.
    def prior(X):
        d=np.maximum(X[:,-1,0],1); dep=X[:,-1,1]; turb=X[:,-1,2]; ac=30-20*np.log10(d/50)-.04*dep-.05*turb; op=35-.012*d-.02*dep-.15*turb
        return np.c_[ac,op,np.clip(.1*10**(-ac/10),1e-8,.5),np.clip(.1*10**(-op/10),1e-8,.5)]
    ptr=prior(Xtr); pte=prior(Xte); rtr=ytr-ptr
    vals=[]
    for s in seeds:
        pr=train_one(PhysicsPIGT(Xtr.shape[-1],16,4),Xtr,rtr,Xte,yte*0+0,s)
        # train_one scales target residual but receives a dummy yte only for signature; add prior back.
        pr=pr+pte; e=yte-pr; vals.append((np.mean(np.abs(e)),np.sqrt(np.mean(e**2)),np.mean(e)))
    v=np.asarray(vals); return [{'model':'PIGT-DT','family':'Physics-informed DT','split':'benchmark','MAE':float(v[:,0].mean()),'RMSE':float(v[:,1].mean()),'Bias':float(v[:,2].mean()),'MAE_std':float(v[:,0].std())}]
