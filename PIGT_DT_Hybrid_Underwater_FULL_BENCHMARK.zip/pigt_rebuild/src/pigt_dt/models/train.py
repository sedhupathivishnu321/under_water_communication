from pathlib import Path
import numpy as np, pandas as pd, torch
from torch.utils.data import TensorDataset,DataLoader
from sklearn.preprocessing import StandardScaler
from .graph_temporal import GraphTemporalResidual, Ensemble
from .losses import gaussian_nll
from ..physics.prior import physics_prior

class Predictor:
    def __init__(self,cfg):
        self.cfg=cfg; self.features=cfg['data']['feature_columns']; self.targets=cfg['data']['target_columns']; self.L=cfg['data']['sequence_length']; self.H=cfg['data']['horizon']; self.xs=StandardScaler(); self.ys=StandardScaler(); self.models=[]
    def sequences(self,df):
        X=[]; Y=[]; groups=[]
        for gid,g in df.groupby('environment_id'):
            g=g.sort_values('timestamp_s'); x=g[self.features].to_numpy(float); y=g[self.targets].to_numpy(float)
            for i in range(self.L,len(g)-self.H+1): X.append(x[i-self.L:i]); Y.append(y[i+self.H-1]); groups.append(gid)
        return np.asarray(X),np.asarray(Y),groups
    def fit(self,train,val):
        X,y,_=self.sequences(train); Xv,yv,_=self.sequences(val)
        prior=physics_prior(X[:,-1]); prior_v=physics_prior(Xv[:,-1]); y_res=y-prior; yv_res=yv-prior_v
        self.xs.fit(X.reshape(-1,X.shape[-1])); self.ys.fit(y_res)
        X=self.xs.transform(X.reshape(-1,X.shape[-1])).reshape(X.shape); y=self.ys.transform(y_res); Xv=self.xs.transform(Xv.reshape(-1,Xv.shape[-1])).reshape(Xv.shape); yv=self.ys.transform(yv_res)
        device='cuda' if self.cfg['training']['device']=='auto' and torch.cuda.is_available() else ('cpu' if self.cfg['training']['device']=='auto' else self.cfg['training']['device'])
        ds=DataLoader(TensorDataset(torch.tensor(X,dtype=torch.float32),torch.tensor(y,dtype=torch.float32)),batch_size=self.cfg['training']['batch_size'],shuffle=True)
        ens=[]
        for seed in self.cfg['experiments']['seeds'][:self.cfg['model']['ensemble_size']]:
            torch.manual_seed(seed); m=GraphTemporalResidual(X.shape[-1],y.shape[-1],self.cfg['model']['hidden'],self.cfg['model']['layers'],self.cfg['model']['dropout']).to(device); opt=torch.optim.AdamW(m.parameters(),lr=self.cfg['training']['lr'],weight_decay=self.cfg['training']['weight_decay']); best=1e99; bad=0
            for ep in range(self.cfg['training']['epochs']):
                m.train()
                for xb,yb in ds:
                    mu,lv=m(xb.to(device)); loss=gaussian_nll(mu,lv.exp(),yb.to(device)); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(m.parameters(),5); opt.step()
                m.eval();
                with torch.no_grad(): mu,lv=m(torch.tensor(Xv,dtype=torch.float32).to(device)); vl=gaussian_nll(mu,lv.exp(),torch.tensor(yv,dtype=torch.float32).to(device)).item()
                if vl<best-1e-4: best=vl; bad=0; best_state={k:v.detach().cpu().clone() for k,v in m.state_dict().items()}
                else: bad+=1
                if bad>=self.cfg['training']['patience']: break
            m.load_state_dict(best_state); ens.append(m.cpu())
        self.models=ens; return self
    def predict(self,X):
        xt=self.xs.transform(X.reshape(-1,X.shape[-1])).reshape(X.shape); t=torch.tensor(xt,dtype=torch.float32); E=Ensemble(self.models); E.eval();
        with torch.no_grad(): mu,var=E(t)
        mu_res=self.ys.inverse_transform(mu.numpy()); var_res=var.numpy()*(self.ys.scale_**2); prior=physics_prior(X[:,-1]); return prior+mu_res,np.sqrt(var_res)

    def load(self,path):
        ck=torch.load(path,map_location='cpu',weights_only=False)
        self.xs.mean_=ck['x_mean']; self.xs.scale_=ck['x_scale']; self.xs.var_=self.xs.scale_**2; self.xs.n_features_in_=len(self.xs.mean_)
        self.ys.mean_=ck['y_mean']; self.ys.scale_=ck['y_scale']; self.ys.var_=self.ys.scale_**2; self.ys.n_features_in_=len(self.ys.mean_)
        self.models=[]
        for st in ck['state']:
            m=GraphTemporalResidual(len(self.features),len(self.targets),self.cfg['model']['hidden'],self.cfg['model']['layers'],self.cfg['model']['dropout']); m.load_state_dict(st); m.eval(); self.models.append(m)
        return self
    def save(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True); torch.save({'state':[m.state_dict() for m in self.models],'x_mean':self.xs.mean_,'x_scale':self.xs.scale_,'y_mean':self.ys.mean_,'y_scale':self.ys.scale_,'features':self.features,'targets':self.targets},path)
