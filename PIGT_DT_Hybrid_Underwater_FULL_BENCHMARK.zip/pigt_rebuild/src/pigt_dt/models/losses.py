import torch

def gaussian_nll(mu,var,y):
    return 0.5*(torch.log(var)+(y-mu)**2/var).mean()
