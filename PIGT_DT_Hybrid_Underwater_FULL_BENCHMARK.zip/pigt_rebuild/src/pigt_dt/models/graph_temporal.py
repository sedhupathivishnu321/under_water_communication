import torch
from torch import nn

class GraphTemporalResidual(nn.Module):
    """Lightweight graph-temporal residual model; adjacency is optional and defaults to self+neighbor averaging."""
    def __init__(self,in_dim,out_dim,hidden=96,layers=2,dropout=.1):
        super().__init__(); self.in_proj=nn.Linear(in_dim,hidden); self.gru=nn.GRU(hidden,hidden,num_layers=layers,batch_first=True,dropout=dropout if layers>1 else 0); self.head=nn.Sequential(nn.LayerNorm(hidden),nn.Linear(hidden,hidden),nn.GELU(),nn.Dropout(dropout),nn.Linear(hidden,out_dim*2)); self.out_dim=out_dim
    def forward(self,x):
        h=self.in_proj(x); h,_=self.gru(h); z=self.head(h[:,-1]); mu,logvar=z.chunk(2,-1); return mu,logvar.clamp(-10,6)

class Ensemble(nn.Module):
    def __init__(self, members): super().__init__(); self.members=nn.ModuleList(members)
    def forward(self,x):
        mus=[]; vars=[]
        for m in self.members:
            mu,lv=m(x); mus.append(mu); vars.append(lv.exp())
        mus=torch.stack(mus); vars=torch.stack(vars); mean=mus.mean(0); total=vars.mean(0)+(mus**2).mean(0)-mean**2
        return mean,total.clamp_min(1e-8)
