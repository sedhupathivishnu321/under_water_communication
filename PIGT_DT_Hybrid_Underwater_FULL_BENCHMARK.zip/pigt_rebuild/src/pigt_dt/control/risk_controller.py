import numpy as np

class RiskController:
    def __init__(self,cfg): self.cfg=cfg
    def choose(self,pred,sigma):
        # pred order: AC snr, ber, pdr, rate, OP snr, ber, pdr, rate
        c=self.cfg['controller']; candidates=[]
        for mode,off in [('AC',0),('OP',4)]:
            ber=float(pred[off+1]+1.64*sigma[off+1]); pdr=float(pred[off+2]-1.64*sigma[off+2]); rate=float(max(0,pred[off+3]-1.64*sigma[off+3])); snr=float(pred[off]+1.64*sigma[off])
            feasible=(ber<=c['max_ber'] and pdr>=c['min_pdr'] and rate>=c['rate_min_kbps'])
            if feasible: candidates.append((rate,mode,snr,ber,pdr))
        if candidates: return max(candidates,key=lambda z:z[0])
        # HYB is conservative fallback: select modality with higher risk-adjusted PDR.
        ac=float(pred[2]-1.64*sigma[2]); op=float(pred[6]-1.64*sigma[6]); return (max(ac,op),'HYB',max(float(pred[0]),float(pred[4])),max(float(pred[1]),float(pred[5])),max(ac,op))
