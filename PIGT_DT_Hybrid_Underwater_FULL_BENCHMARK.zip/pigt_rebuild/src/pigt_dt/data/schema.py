TARGETS = ['ac_snr_db','ac_ber','ac_pdr','ac_rate_kbps','op_snr_db','op_ber','op_pdr','op_rate_kbps']
FEATURES = ['distance_m','depth_m','temperature_c','salinity_ppt','turbidity_ntu','ac_snr_db','ac_ber','ac_pdr','ac_rate_kbps','op_snr_db','op_ber','op_pdr','op_rate_kbps','channel_age_s']
META = ['dataset','environment_id','station_id','timestamp_s']

def validate(df):
    required = set(FEATURES + TARGETS + META)
    missing = sorted(required - set(df.columns))
    if missing: raise ValueError('Missing columns: ' + ', '.join(missing))
    return True
