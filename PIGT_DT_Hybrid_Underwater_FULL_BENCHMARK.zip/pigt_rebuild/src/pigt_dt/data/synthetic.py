import numpy as np, pandas as pd

def make_benchmark_dataframe(seed=2026,environments=36,steps=180):
    rng=np.random.default_rng(seed); rows=[]
    for e in range(environments):
        d0=rng.uniform(80,1200); depth0=rng.uniform(5,120); turb0=rng.uniform(.1,15); phase=rng.uniform(0,6.28)
        for t in range(steps):
            d=np.clip(d0+80*np.sin(t/35+phase)+rng.normal(0,8),30,1800); depth=np.clip(depth0+10*np.sin(t/55)+rng.normal(0,1),2,180); turb=np.clip(turb0+2*np.sin(t/40+phase)+rng.normal(0,.25),.02,25)
            ac=32-20*np.log10(d/50)-.045*depth-.055*turb+2*np.sin(t/17+phase)+rng.normal(0,1.2)
            op=34-.013*d-.018*depth-.22*turb+1.5*np.cos(t/23+phase)+rng.normal(0,1.4)
            en=100-.08*t+5*np.sin(t/70+phase)+rng.normal(0,.3)
            rows.append([e,t,d,depth,turb,ac,op,np.clip(.1*10**(-ac/10),1e-8,.5),np.clip(.1*10**(-op/10),1e-8,.5),en])
    return pd.DataFrame(rows,columns=['environment_id','timestamp_s','distance_m','depth_m','turbidity','ac_snr_db','op_snr_db','ac_ber','op_ber','energy'])

def make_dataset(n_env=2,steps=20,seed=2026):
    rng=np.random.default_rng(seed); rows=[]
    for e in range(n_env):
        for t in range(steps):
            d=float(rng.uniform(50,1000)); dep=float(rng.uniform(5,150)); temp=float(5+rng.normal()); sal=float(35+rng.normal(0,.5)); turb=float(rng.uniform(.1,20)); ac=float(30-20*np.log10(d/50)-.04*dep-.05*turb+rng.normal()); op=float(35-.012*d-.02*dep-.15*turb+rng.normal());
            ab=float(np.clip(.1*10**(-ac/10),1e-8,.5)); ob=float(np.clip(.1*10**(-op/10),1e-8,.5)); ap=float(np.clip(1-ab,0,1)); opdr=float(np.clip(1-ob,0,1)); ar=float(np.clip(10**(ac/10)*10,0,5000)); opr=float(np.clip(10**(op/10)*10,0,5000));
            rows.append([e,t,d,dep,temp,sal,turb,ac,ab,ap,ar,op,ob,opdr,opr,0])
    return pd.DataFrame(rows,columns=['environment_id','timestamp_s','distance_m','depth_m','temperature_c','salinity_ppt','turbidity_ntu','ac_snr_db','ac_ber','ac_pdr','ac_rate_kbps','op_snr_db','op_ber','op_pdr','op_rate_kbps','channel_age_s'])
