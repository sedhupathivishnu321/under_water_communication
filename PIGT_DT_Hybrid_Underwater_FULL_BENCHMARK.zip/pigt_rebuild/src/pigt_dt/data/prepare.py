from pathlib import Path
import pandas as pd
from .synthetic import make_dataset

def load_csvs(root):
    root=Path(root); frames=[]
    for p in root.rglob('*.csv'):
        try:
            df=pd.read_csv(p); df['source_file']=str(p); frames.append(df)
        except Exception: pass
    return pd.concat(frames,ignore_index=True) if frames else pd.DataFrame()

def standardize(df):
    aliases={'range_m':'distance_m','distance':'distance_m','depth':'depth_m','temperature':'temperature_c','salinity':'salinity_ppt','turbidity':'turbidity_ntu','SNR_acoustic':'ac_snr_db','BER_acoustic':'ac_ber','PDR_acoustic':'ac_pdr','throughput_acoustic':'ac_rate_kbps','SNR_optical':'op_snr_db','BER_optical':'op_ber','PDR_optical':'op_pdr','throughput_optical':'op_rate_kbps'}
    df=df.rename(columns={k:v for k,v in aliases.items() if k in df.columns}).copy()
    defaults={'dataset':'unknown','environment_id':'unknown','station_id':-1,'timestamp_s':range(len(df)),'distance_m':100.0,'depth_m':20.0,'temperature_c':15.0,'salinity_ppt':35.0,'turbidity_ntu':1.0,'ac_snr_db':10.0,'ac_ber':1e-3,'ac_pdr':0.95,'ac_rate_kbps':10.0,'op_snr_db':10.0,'op_ber':1e-3,'op_pdr':0.95,'op_rate_kbps':10.0,'channel_age_s':0.0}
    for c,v in defaults.items():
        if c not in df.columns: df[c]=v
    for c in ['station_id','timestamp_s']: df[c]=pd.to_numeric(df[c],errors='coerce').fillna(-1)
    return df

def prepare(input_dir, output, synthetic_if_empty=True):
    df=load_csvs(input_dir)
    if df.empty and synthetic_if_empty: df=make_dataset()
    df=standardize(df); Path(output).parent.mkdir(parents=True,exist_ok=True); df.to_csv(output,index=False); return df
