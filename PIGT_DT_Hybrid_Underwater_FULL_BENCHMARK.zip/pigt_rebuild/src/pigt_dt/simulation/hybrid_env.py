import numpy as np

class HybridEnv:
    def __init__(self,nodes=8,steps=200,seed=2026): self.nodes=nodes; self.steps=steps; self.rng=np.random.default_rng(seed); self.reset()
    def reset(self): self.t=0; self.energy=np.full(self.nodes,100.0); return self._obs()
    def _obs(self):
        d=self.rng.uniform(50,1000,self.nodes); depth=self.rng.uniform(5,150,self.nodes); turb=self.rng.uniform(.1,20,self.nodes); ac=30-20*np.log10(d/50)-.04*depth-.05*turb+self.rng.normal(0,1,self.nodes); op=35-.012*d-.02*depth-.15*turb+self.rng.normal(0,1,self.nodes); return np.stack([d,depth,turb,ac,op,self.energy],1)
    def step(self,actions):
        actions=np.asarray(actions); mode=actions[:,0]; power=np.clip(actions[:,1],0,20); self.energy-=0.02*power+0.1; self.t+=1; snr=np.where(mode<0.5,self._obs()[:,3],self._obs()[:,4]); pdr=np.clip(1-np.exp(-np.maximum(snr,-5)/8),0,1); rate=np.clip(10**(snr/10)*10,0,5000); ber=np.clip(1e-1*10**(-snr/10),1e-8,.5); reward=float(np.mean(rate*pdr-20*ber-0.5*power)); done=self.t>=self.steps; return self._obs(),reward,done,{'pdr':float(pdr.mean()),'rate_kbps':float(rate.mean()),'ber':float(ber.mean()),'energy':float(self.energy.mean())}
