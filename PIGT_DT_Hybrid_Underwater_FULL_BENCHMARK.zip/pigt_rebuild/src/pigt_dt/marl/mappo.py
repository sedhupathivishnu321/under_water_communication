import torch
from torch import nn
from torch.distributions import Categorical

class Actor(nn.Module):
    def __init__(self,obs_dim,actions=3): super().__init__(); self.net=nn.Sequential(nn.Linear(obs_dim,128),nn.Tanh(),nn.Linear(128,128),nn.Tanh(),nn.Linear(128,actions))
    def forward(self,x): return self.net(x)

class CentralCritic(nn.Module):
    def __init__(self,state_dim): super().__init__(); self.net=nn.Sequential(nn.Linear(state_dim,256),nn.Tanh(),nn.Linear(256,128),nn.Tanh(),nn.Linear(128,1))
    def forward(self,x): return self.net(x).squeeze(-1)

class MAPPO:
    """Minimal CTDE MAPPO building block for discrete AC/OP/HYB mode selection."""
    def __init__(self,obs_dim,state_dim,agents=4,lr=3e-4):
        self.actors=nn.ModuleList([Actor(obs_dim) for _ in range(agents)]); self.critic=CentralCritic(state_dim); self.opt=torch.optim.Adam(list(self.actors.parameters())+list(self.critic.parameters()),lr=lr)
    def act(self,obs):
        acts=[]; logp=[]
        for i,a in enumerate(self.actors):
            d=Categorical(logits=a(obs[:,i])); q=d.sample(); acts.append(q); logp.append(d.log_prob(q))
        return torch.stack(acts,1),torch.stack(logp,1)
    def value(self,state): return self.critic(state)
