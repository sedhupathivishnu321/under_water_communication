import numpy as np

def acoustic_prior(x):
    d=np.maximum(x[...,0],10); depth=x[...,1]; turb=x[...,4]
    return 30-20*np.log10(d/50)-0.04*depth-0.05*turb

def optical_prior(x):
    d=np.maximum(x[...,0],1); depth=x[...,1]; turb=x[...,4]
    return 35-0.012*d-0.02*depth-0.15*turb

def physics_prior(x):
    a=acoustic_prior(x); o=optical_prior(x)
    return np.stack([a,np.zeros_like(a),np.clip(1-np.exp(-np.maximum(a,-5)/10),0,1),10**(a/12),o,np.zeros_like(o),np.clip(1-np.exp(-np.maximum(o,-5)/10),0,1),10**(o/10)],axis=-1)
