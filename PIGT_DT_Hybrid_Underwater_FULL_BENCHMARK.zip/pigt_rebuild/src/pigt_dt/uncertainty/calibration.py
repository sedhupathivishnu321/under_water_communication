import numpy as np

def gaussian_interval(mu,sigma,coverage=.90):
    from scipy.stats import norm
    z=norm.ppf((1+coverage)/2); return mu-z*sigma,mu+z*sigma

def calibration_metrics(y,mu,sigma,coverage=.90):
    lo,hi=gaussian_interval(mu,sigma,coverage); covered=((y>=lo)&(y<=hi)).mean(); width=(hi-lo).mean(); nll=(0.5*np.log(2*np.pi*sigma**2)+0.5*((y-mu)/sigma)**2).mean()
    return {'coverage':float(covered),'mean_interval_width':float(width),'nll':float(nll)}
