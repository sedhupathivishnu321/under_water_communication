# Real-data integration guide

## ALOMEX 2015
Primary multimodal dataset. It contains simultaneously measured acoustic and optical link characteristics from nine stations during the NATO ALOMEX 2015 expedition. Use station/environment IDs for splitting.

## Underwater Acoustic Channel Library
Use measured channel impulse responses for external acoustic validation and channel replay. Extract channel statistics such as delay spread, received power/SNR and time variability before mapping into the unified schema.

## UWOC CSV data
The Zenodo OFDM-UWVC dataset provides experimental BER and throughput under multiple water conditions and distances. Map distance and condition metadata into the optical schema. Do not invent depth/salinity/turbidity values when they are absent.

## Unified schema
Required fields are documented in `src/pigt_dt/data/schema.py`. Fields that are genuinely unavailable should remain missing in a research dataset; the default filler values exist only to keep the demo executable.
