# Existing works and baselines to compare

This project separates **implemented baselines** from **literature reference systems**. A literature system should only be claimed as reproduced when its algorithm, parameters, data, and evaluation protocol are actually implemented.

## Direct DT/UASN references
- DTNA — Digital Twin-based Intelligent Network Architecture for UASN (source paper supplied by the project).
- RAPD — DT-assisted local resource allocation/prediction framework in DTNA.
- PC-MAC / PC-MAC-R / PC-MAC-DT — physical resource/MAC baselines used in the supplied DTNA work.
- DCMD / DCMD-DT — AUV data collection MARL baselines used in the supplied DTNA work.
- TGNSO / TNSD — task-oriented slicing baselines used in the supplied DTNA work.

## Prediction baselines implemented by this repository
Persistence, AR(3), SVR, Random Forest, Extra Trees, Gradient Boosting, LSTM, GRU, TCN, Transformer, GNN-Transformer and PIGT-DT.

## Controller baselines implemented by this repository
Fixed Power, AC-only, OP-only, threshold hybrid, SNR hybrid, energy-aware heuristic, PC-MAC, PC-MAC-DT, MADDPG-labelled control proxy, MAPPO-labelled control proxy and PIGT-DT.

**Important:** the controller entries named MADDPG/MAPPO in the lightweight benchmark are comparison-policy proxies, not a claim of reproducing every detail of a published MARL implementation. The full MAPPO implementation remains under `src/pigt_dt/marl/` and should be trained/evaluated before making a publication claim.

## External datasets / validation sources
- ALOMEX 2015: IMDEA Networks, simultaneous acoustic/optical measurements, DOI 10.1109/TWC.2017.2756055 — https://dspace.networks.imdea.org/handle/20.500.12761/451
- Underwater Acoustic Channel Repository — https://uwa-channels.github.io/
- KAM11 channel data — https://uwa-channels.github.io/channels/yellow/
- UWVC OFDM dataset — https://zenodo.org/records/17256508

## Required comparison metrics
Prediction: MAE, RMSE, bias, NLL, CRPS, interval coverage, interval width, calibration error, OOD error.
Communication: PDR, BER, throughput, latency, energy, switching rate, constraint violations.
Systems: inference time, memory, parameter count, DT update age, communication overhead, scalability.

## Required experiment groups
1. Model comparison.
2. Physics-vs-data ablation.
3. Temporal backbone ablation.
4. Uncertainty/ensemble ablation.
5. Risk constraint ablation.
6. Real/DT data ratio.
7. Model-form mismatch.
8. Node-scale sweep.
9. Sensor/channel failure.
10. DT staleness.
11. Acoustic/optical/hybrid mode comparison.
12. Independent real-data validation.
