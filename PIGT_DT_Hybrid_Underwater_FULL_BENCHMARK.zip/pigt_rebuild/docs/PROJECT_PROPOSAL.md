# Project Proposal

## Title
Physics-Informed Uncertainty-Aware Graph-Temporal Digital Twin for Adaptive Hybrid Underwater Acoustic–Optical Communication

## Novelty
1. Real-data-first DT predictor using multimodal underwater measurements.
2. Physics-prior residual learning instead of unconstrained black-box prediction.
3. Calibrated uncertainty for OOD and unsafe-channel detection.
4. Adaptive AC/OP/HYB communication under BER/PDR/rate/energy constraints.
5. Independent simulator/model-form tests to reduce circular DT evaluation.

## Core hypothesis
A calibrated physics-informed DT can predict near-future heterogeneous link quality more reliably under environment/model mismatch than physics-only or data-only predictors, and uncertainty-aware decisions can reduce constraint violations at comparable energy cost.

## Baselines
Physics-only; persistence; linear regression; random forest/XGBoost; LSTM/GRU; TCN; Transformer; GNN-temporal; single probabilistic network; ensemble; unconstrained controller; rule-based AC/OP switching; constrained controller.

## Deliverables
Dataset adapters, preprocessing pipeline, DT predictor, uncertainty module, hybrid controller, independent simulation environment, ablation runner, evaluation plots, model checkpoints, experiment logs and reproducibility package.
