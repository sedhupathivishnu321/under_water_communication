# Methodology

## 1. Data
Real measurements are the primary source. The pipeline accepts station-level CSVs and normalizes them into a common schema. Missing variables are filled only for demonstration/smoke operation; in a publication, every imputed field must be identified and sensitivity-tested.

## 2. Physics-informed DT
A deterministic acoustic and optical prior maps distance, depth and turbidity to coarse link-quality estimates. The learned model predicts the residual between measured targets and this prior. This makes the contribution testable through physics-only, data-only and physics+residual ablations.

## 3. Temporal predictor
A GRU-based temporal backbone maps the recent history of channel/network observations to eight future targets: acoustic SNR/BER/PDR/rate and optical SNR/BER/PDR/rate. The production experiment should compare GRU, TCN, LSTM and Transformer variants.

## 4. Uncertainty
An ensemble provides epistemic-plus-aleatoric uncertainty. Evaluate negative log likelihood, empirical interval coverage, interval width/sharpness, calibration error and OOD calibration. A future implementation may add quantile regression and conformal prediction.

## 5. Control
The risk controller evaluates AC and OP candidates with uncertainty-adjusted constraints and uses HYB as a conservative fallback. A full research implementation should add CTDE MAPPO only after the predictor is independently validated. Policy training must use an independent environment from the predictor's training generator.

## 6. Evaluation
Use environment/station-level splits. Report multiple random seeds, confidence intervals, paired tests where appropriate, and effect sizes. Evaluate model-form mismatch, OOD, sensor failure, DT staleness, scale, inference latency and communication overhead.

## 7. Publication boundary
The included synthetic generator is for software validation. It is not a substitute for ALOMEX, measured acoustic channels or measured optical data. No result from the smoke run should be presented as a real-data result.
