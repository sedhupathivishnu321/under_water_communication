# Reproducibility checklist

- Record Python/PyTorch versions.
- Store config with every experiment.
- Use fixed seeds and report all seeds.
- Save train/validation/test environment IDs.
- Keep raw third-party datasets outside the repository unless licenses allow redistribution.
- Save model checkpoints and scalers.
- Never mix future samples from an environment into training.
- Report all failed runs and all ablations.
- Separate smoke-test outputs from scientific results.
