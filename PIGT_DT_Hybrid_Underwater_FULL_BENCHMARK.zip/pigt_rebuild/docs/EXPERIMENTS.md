# Experiment Matrix

| ID | Experiment | Main question | Metrics |
|---|---|---|---|
| E1 | Real-data prediction | Does DT predict future link quality? | MAE, RMSE, R2, NLL |
| E2 | Uncertainty | Is uncertainty calibrated? | coverage, width, NLL, ECE |
| E3 | Physics ablation | Does physics prior help? | E1 metrics |
| E4 | Temporal backbone | Which temporal representation is robust? | E1 + latency |
| E5 | OOD | Does DT generalize to unseen environments? | error, calibration |
| E6 | Model mismatch | Does the DT survive incorrect physics? | error, safety |
| E7 | Controller | Do DT predictions improve decisions? | PDR, BER, rate, delay, energy |
| E8 | Scale | How does performance scale? | control metrics, latency, memory |
| E9 | Failure | Does uncertainty trigger safe fallback? | violation rate |
| E10 | Staleness | How often must DT refresh? | error vs age, overhead |

## Required plots
1. Predicted vs measured SNR.
2. Predicted vs measured BER/PDR/rate.
3. Residual distribution.
4. Reliability/calibration diagram.
5. Prediction interval coverage vs width.
6. Error vs channel age.
7. Error vs distance/depth/turbidity.
8. OOD error by environment.
9. PDR vs energy trade-off.
10. Throughput vs latency.
11. BER vs power/rate.
12. AC/OP/HYB mode switching timeline.
13. Scale vs inference latency.
14. Ablation forest/bar plots with confidence intervals.
15. Sim-to-real/model-mismatch degradation.
