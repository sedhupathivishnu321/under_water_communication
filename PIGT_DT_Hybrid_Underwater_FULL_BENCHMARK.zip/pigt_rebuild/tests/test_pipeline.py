import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from pigt_dt.data.synthetic import make_dataset
from pigt_dt.data.prepare import standardize
from pigt_dt.physics.prior import physics_prior
from pigt_dt.uncertainty.calibration import calibration_metrics

def test_synthetic_schema():
    df=make_dataset(n_env=2,steps=20); assert len(df)==40; assert 'ac_snr_db' in df.columns

def test_physics_shape():
    df=make_dataset(n_env=1,steps=3); x=df[['distance_m','depth_m','temperature_c','salinity_ppt','turbidity_ntu','ac_snr_db']].to_numpy(); p=physics_prior(x); assert p.shape==(3,8)

def test_calibration():
    import numpy as np
    y=np.zeros((10,2)); m=np.zeros_like(y); s=np.ones_like(y); r=calibration_metrics(y,m,s); assert 0<=r['coverage']<=1
